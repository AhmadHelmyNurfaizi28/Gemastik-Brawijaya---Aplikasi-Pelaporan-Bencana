<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="{{asset('assets/css/Nolap.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/styleguide.css')}}">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="detail-user screen">
        <div class="flex-row">
            <div class="nowadays-it-isnt-g">SADEWA</div>
        <img class="sadewa-1" src="{{asset('image/Sadewa.webp')}}" alt="sadewa-1" />
        </div>
        <div class="overlap-group4">
            <div class="nomor-laporan">Nomor Laporan</div>
            <div class="phone">150721001</div>
        </div>        
        <div class="overlap-group3">
            
            <div class="judul-laporan paragraph18">Judul Laporan&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</div>
            
            <div class="group-210">

                <div class="overlap-group2">
                    <div class="tanggal-kejadian paragraph18">Tanggal Kejadian&nbsp;&nbsp; :</div>
                <div class="date inter-normal-black-18px">15/07/2021</div>
                </div>
                <div class="bencana-container">
                    <div class="kategori-bencana paragraph18">Kategori Bencana :</div>
        <div class="bencana-non-alam inter-normal-black-18px">Bencana Non Alam</div>
                </div>
                <div class="overlap-group">
                    <div class="isi-laporan paragraph18">Isi Laporan&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</div>
                    <div class="alamat-kejadian paragraph18">Alamat Kejadian&nbsp;&nbsp;&nbsp;&nbsp;:</div>
                    <div class="bukti paragraph18">
                        Bukti&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:
                    </div>
                    <div class="kebakaran-yang-terj inter-normal-black-18px">Kebakaran Yang Terjadi Akibat Konslet Listrik</div>
                    <div class="ruko-gardenia-jl-g inter-normal-black-18px">Ruko Gardenia,Jl.Gatot Subroto,Jakarta Pusat</div>
                </div>
                <div class="kebakaran-di-pakubuwono inter-normal-black-18px">Kebakaran di pakubuwono</div>
                <img class="image-13" src="{{asset('image/pakubuwono.jpg')}}" alt="image 13"/>
            </div>
            <div class=" terima-kasih-atas-la">
                Terimakasih Atas laporan yang telah anda buat.<br/>Laporan akan segera di proses sesuai SOP yang berlaku di instansi terkait<br/> <by:https:>
            </div>
        </div> 
</body>
</html>
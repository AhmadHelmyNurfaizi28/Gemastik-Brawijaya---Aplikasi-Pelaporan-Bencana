<h1>Instalasi penggunaan laravel</h1>
<h4>clone repo</h4>
<p>copy file .env.example</p>
<p>run composer install/composer update</p>
<p>edit file .env lalu ganti nama db, host,username,password, base url</p>
<h5>import file sql</h5>
